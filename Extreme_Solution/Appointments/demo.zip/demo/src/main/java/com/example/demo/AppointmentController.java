package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Appointment;
import com.example.demo.AppointmentRepo;

@RestController
public class AppointmentController {

	@Autowired
	private AppointmentRepo repository;

	@PostMapping("/book")
	public String saveBook(@RequestBody Appointment a) {
		repository.save(a);
		return "Added booking with doc : " + a.doc;
	}

	@GetMapping("/schedule")
	public List<Appointment> getBooks() {
		return repository.findAll();
	}



}