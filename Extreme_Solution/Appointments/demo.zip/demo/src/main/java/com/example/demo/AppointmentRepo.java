package com.example.demo;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.demo.Appointment;


public interface AppointmentRepo extends MongoRepository<Appointment, Object> {

}
