package com.example.demo;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

//import lombok.Getter;
//import lombok.Setter;
//import lombok.ToString;
//
//@Getter
//@Setter
//@ToString

@Document(collection = "Appointment")


public class Appointment {
	
//	public int id ;
	public String doc;
	public String patient;
	public String day;
	public String slot;
//	public int getId() {
//		
////		return id;
//	}
}
